package com.sun.faces.test.agnostic.vdl.facelets.repeatStateMap;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Named;

@Named
@RequestScoped
public class UserBean implements Serializable {
    private static final long serialVersionUID = -6249152971686287687L;
    
    private List<String> fruit;
    private Map<String, String> fruitValues;

    @PostConstruct
    private void init() {
        fruit = new ArrayList<>();
        fruit.add("apple");
        fruit.add("orange");
        fruit.add("pear");
        fruit.add("banana");
        
        fruitValues = new HashMap<>();
    }
    
    public List<String> getFruit() {
        return fruit;
    }
    
    public Map<String, String> getFruitValues() {
        return fruitValues;
    }
    
}

